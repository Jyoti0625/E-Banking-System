import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.util.*;
import java.util.Random;
public class NewAccount extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)throws IOException, ServletException
{
res.setContentType("text/html");
PrintWriter out=res.getWriter();
String user=req.getParameter("txtname");
String adhar=req.getParameter("adharno");
String mobile=req.getParameter("emailname");
String email=req.getParameter("mobile");
String father=req.getParameter("fathername");
String accounttype=req.getParameter("accounttype");
String balance=req.getParameter("balance");
String gender=req.getParameter("gendername");
String update="";
Random random=new Random();
String s="1234567890";
char[] otp=new char[11];
for(int i=0;i<11;i++)
{
otp[i]=s.charAt(random.nextInt(s.length()));
}
String strArray[]=new String[otp.length];
for(int i=0;i<otp.length;i++)
{
strArray[i]=String.valueOf(otp[i]);
}
String s1=Arrays.toString(strArray);
String res1="";
for(String num:strArray)
{
res1+=num;
}

try{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
PreparedStatement ps=con.prepareStatement("insert into accountdata1 values(?,?,?,?,?,?,?,?,?,?)");
ps.setString(1,user);
ps.setString(2,res1);
ps.setString(3,adhar);
ps.setString(4,email);
ps.setString(5,mobile);
ps.setString(6,father);
ps.setString(7,accounttype);
ps.setString(8,balance);
ps.setString(9,gender);
ps.setString (10,update);
ps.executeUpdate();
PreparedStatement ps1=con.prepareStatement("select* from accountdata1 where account_number='"+res1+"'");
ResultSet rs=ps1.executeQuery();
while(rs.next())
{
out.println("<br>name="+rs.getString(1));
out.println("<br>account="+rs.getString(2));
out.println("<br>adhar="+rs.getString(3));
out.println("<br>email="+rs.getString(4));
out.println("<br>mobile="+rs.getString(5));
out.println("<br>father="+rs.getString(6));
out.println("<br>accounttype="+rs.getString(7));
out.println("<br>balance="+rs.getString(8));
out.println("<br>gender="+rs.getString(9));
}
RequestDispatcher rd=req.getRequestDispatcher("Homepage.html");
rd.include(req,res);
out.println("<br>registered succesfully");
}
catch(Exception e)
{
out.println(e);
}
out.close();
}

}

