import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.swing.*;
public class Login extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException 
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
String u=req.getParameter("UserType");
String n=req.getParameter("txtname");
String p=req.getParameter("passname");
HttpSession session=req.getSession();
session.setAttribute("name",n);
try
{
int flag=0;

Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
Statement s=con.createStatement();
if(u.equals("User"))
{
ResultSet rs=s.executeQuery("select USER_NAME,USER_PASS from Employeeuser");
while(rs.next())
{
if(n.equals(rs.getString(1))&& p.equals(rs.getString(2)))
{
pw.println("welcome" +n);

RequestDispatcher rd=req.getRequestDispatcher("Homepage.html");
rd.include(req,res);
flag=1;
break;
}
}
if(flag==0)
{
JOptionPane.showMessageDialog(null,"invalid username or password","Alert Message",JOptionPane.WARNING_MESSAGE);
RequestDispatcher rd=req.getRequestDispatcher("index.html");
rd.include(req,res);
}
}
else
{
if(u.equals("jyoti")&&p.equals("Admin"))
{
pw.println("welcome"+n);
RequestDispatcher rd1=req.getRequestDispatcher("Accountdetails.html");
rd1.forward(req,res);
}
else
{
JOptionPane.showMessageDialog(null,"invalid username or password","Alert Message",JOptionPane.WARNING_MESSAGE);
RequestDispatcher rd1=req.getRequestDispatcher("index.html");
rd1.include(req,res);
}
}
}
catch(Exception e)
{
System.out.println(e);
}
}
}