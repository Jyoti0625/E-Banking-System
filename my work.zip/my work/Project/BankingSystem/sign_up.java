import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class sign_up extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException 
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
String n=req.getParameter("UName");
 String p=req.getParameter("UPass");
 String e=req.getParameter("Email");
 String c=req.getParameter("Contact_no");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
PreparedStatement ps=con.prepareStatement("insert into Employeeuser values(?,?,?,?)");
ps.setString(1,n);
ps.setString(2,p);
ps.setString(3,e);
ps.setString(4,c);
int i=ps.executeUpdate();

if(i>0)
{
 

RequestDispatcher rd=req.getRequestDispatcher("login.html");
rd.include(req,res);
pw.println("Hello"+n+" you are succesfully Registered");

}

}
catch(Exception e1)
{
System.out.println(e1);
}
}
}