;import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;
public class Changepassword extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
{
res.setContentType("text/html");
PrintWriter out=res.getWriter();
String pass3=req.getParameter("passname3");
String pass1=req.getParameter("passname1");
String pass2=req.getParameter("passname2");
try
{
Class.forName("oracle.jdbc.driver.OrcaleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
Statement s=con.createStatement();
if(pass2.equals(pass3))
{
s.executeUpdate("update employee set password='"+pass2+"' where password='"+pass1+"'");


RequestDispatcher rd=req.getRequestDispatcher("Homepage.html");
out.println("password updated login again");
rd.include(req,res);
}
else
{
JOptionPane.showMessageDialog(null,"passwords donot match","Alert message",JOptionPane.WARNING_MESSAGE);
RequestDispatcher rd=req.getRequestDispatcher("Changepassword.html");
rd.include(req,res);
}
}
catch(Exception e){}
}
}